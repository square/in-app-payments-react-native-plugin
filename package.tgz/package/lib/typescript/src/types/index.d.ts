export interface ErrorDetails {
    debugMessage: string;
    message: string;
    code?: string;
    debugCode?: string;
}
export interface ColorType {
    r: number;
    g: number;
    b: number;
    a?: number;
}
export declare const ErrorCodes: {
    UsageError: string;
};
export interface FontType {
    size: number;
    name?: string;
}
export interface ThemeType {
    font?: FontType;
    saveButtonFont?: FontType;
    backgroundColor?: ColorType;
    textColor?: ColorType;
    placeholderTextColor?: ColorType;
    tintColor?: ColorType;
    messageColor?: ColorType;
    errorColor?: ColorType;
    saveButtonTitle?: string;
    saveButtonTextColor?: ColorType;
    keyboardAppearance?: 'Light' | 'Dark';
    cancelButton?: any;
}
export interface ApplePayConfig {
    price: string;
    summaryLabel: string;
    countryCode: string;
    currencyCode: string;
    paymentType?: PaymentType;
}
export declare enum PaymentType {
    PaymentTypePending = 1,
    PaymentTypeFinal = 2
}
export declare enum Brand {
    OTHER_BRAND = 0,
    VISA = 1,
    MASTERCARD = 2,
    AMERICAN_EXPRESS = 3,
    DISCOVER = 4,
    DISCOVER_DINERS = 5,
    JCB = 6,
    CHINA_UNION_PAY = 7,
    SQUARE_GIFT_CARD = 8
}
export interface VerificationResult {
    nonce?: string;
    token?: string;
}
export interface BuyerVerificationSuccessCallback {
    (verificationResult: VerificationResult): void;
}
export interface CancelAndCompleteCallback {
    (): void;
}
export declare enum PrepaidType {
    UNKNOWN = 0,
    NOT_PREPAID = 1,
    PREPAID = 2
}
export declare enum Type {
    UNKNOWN = 0,
    CREDIT = 1,
    DEBIT = 2
}
export interface Card {
    brand?: Brand;
    lastFourDigits?: string;
    expirationMonth?: number;
    expirationYear?: number;
    postalCode?: string;
    type?: Type;
    prepaidType?: PrepaidType;
}
export interface CardDetails {
    nonce?: string;
    card?: Card;
}
export interface CardEntryConfig {
    collectPostalCode: boolean;
    squareLocationId?: string;
    buyerAction?: 'Charge' | 'Store';
    amount?: number;
    currencyCode?: string;
    givenName?: string;
    familyName?: string;
    addressLines?: string[];
    city?: string;
    countryCode?: string;
    email?: string;
    phone?: string;
    postalCode?: string;
    region?: string;
}
export interface FailureCallback {
    (error: ErrorDetails): void;
}
export declare enum GooglePayPriceStatus {
    TotalPriceStatusNotCurrentlyKnown = 1,
    TotalPriceStatusEstimated = 2,
    TotalPriceStatusFinal = 3
}
export interface GooglePayConfig {
    price: string;
    currencyCode: string;
    priceStatus: GooglePayPriceStatus;
}
export interface NonceSuccessCallback {
    (cardDetails: CardDetails): void;
}
/**
 * @param success - Whether the card entry was successful
 * @param errorMessage - The error message if the card entry was not successful
 * @param onCardEntryComplete - A callback to be called when the card entry is successfully completed
 */
export interface NonceSuccessResult {
    success: boolean;
    errorMessage?: string;
    onCardEntryComplete?: () => void;
}
export declare enum ApplePayNonceSuccessState {
    Succeeded = "succeeded",
    Failure = "failure",
    Canceled = "canceled"
}
export interface ApplePayNonceSuccessResult {
    state: ApplePayNonceSuccessState;
    errorMessage?: string;
}
export type NonceSuccessCallbackWithResult = (cardDetails: CardDetails) => NonceSuccessResult | Promise<NonceSuccessResult>;
export declare enum GooglePayEnvironment {
    EnvironmentProduction = 1,
    EnvironmentTest = 3
}
export interface ApplePayCancelAndCompleteCallback {
    (status: ApplePayNonceSuccessState, errorMessage?: string): void;
}
export type ApplePayNonceSuccessCallbackWithResult = (cardDetails: CardDetails) => ApplePayNonceSuccessResult | Promise<ApplePayNonceSuccessResult>;
//# sourceMappingURL=index.d.ts.map