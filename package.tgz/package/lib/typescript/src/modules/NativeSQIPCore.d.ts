import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    setSquareApplicationId(applicationId: string): void;
    getSquareApplicationId(): string | null;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeSQIPCore.d.ts.map