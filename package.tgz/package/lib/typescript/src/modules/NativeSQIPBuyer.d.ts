import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    startBuyerVerificationFlow(paymentSourceId: string, locationId: string, buyerAction: string, money: Object, contact: Object, onBuyerVerificationSuccess: (verificationResult: Object) => void, onBuyerVerificationFailure: (errorDetails: Object) => void): void;
    setMockBuyerVerificationSuccess(mockBuyerVerificationSuccess: boolean): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeSQIPBuyer.d.ts.map