import { type BuyerVerificationSuccessCallback, type CancelAndCompleteCallback, type CardEntryConfig, type FailureCallback, GooglePayEnvironment, type GooglePayConfig, type NonceSuccessCallback, type NonceSuccessCallbackWithResult, type ThemeType, type ApplePayConfig, type ApplePayNonceSuccessCallbackWithResult, type ApplePayCancelAndCompleteCallback } from './types';
import { GooglePayPriceStatus } from './types';
export * from './types';
export declare namespace SQIPCore {
    function setSquareApplicationId(applicationId: string): void;
    function getSquareApplicationId(): string | null;
}
export declare namespace SQIPCardEntry {
    /**
     * @deprecated Use
     * `startCardEntryFlow(
     *  collectPostalCode: boolean,
     *  onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult,
     *  onCardEntryCancel?: CancelAndCompleteCallback
     * )` instead. Now you don't need to completeCardEntry
     */
    function startCardEntryFlow(config: CardEntryConfig, onCardNonceRequestSuccess: NonceSuccessCallback, onCardEntryCancel: CancelAndCompleteCallback): void;
    function startCardEntryFlow(collectPostalCode: boolean, onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult, onCardEntryCancel?: CancelAndCompleteCallback): void;
    /**
     * @deprecated Use
     * `onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult,`
     *  see `startCardEntryFlow` instead. Now you don't need to completeCardEntry
     *  manually.
     */
    function completeCardEntry(onCardEntryComplete?: CancelAndCompleteCallback): void;
    /**
     * @deprecated Use
     * `onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult,`
     *  see `startCardEntryFlow`. Now you don't need
     *  to showCardNonceProcessingError manually.
     */
    function showCardNonceProcessingError(errorMessage: string): void;
    function startGiftCardEntryFlow(onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult, onCardEntryCancel?: CancelAndCompleteCallback): void;
    /**
     * @deprecated Use
     * `startGiftCardEntryFlow(
     *  onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult,
     *  onCardEntryCancel?: CancelAndCompleteCallback
     * )` instead. Now you don't need to completeCardEntry
     */
    function startGiftCardEntryFlow(onCardNonceRequestSuccess: NonceSuccessCallback, onCardEntryCancel: CancelAndCompleteCallback): void;
    /**
     * @deprecated Use
     * `SQIPBuyer.startBuyerVerificationFlow(
     *  paymentSourceId: string,
     *  cardEntryConfig: CardEntryConfig,
     *  onBuyerVerificationSuccess?: BuyerVerificationSuccessCallback,
     *  onBuyerVerificationFailure?: FailureCallback,
     * )` instead.
     */
    function startBuyerVerificationFlow(paymentSourceId: string, cardEntryConfig: CardEntryConfig, onBuyerVerificationSuccess: BuyerVerificationSuccessCallback, onBuyerVerificationFailure: FailureCallback, onCardEntryCancel: CancelAndCompleteCallback): void;
    function startCardEntryFlowWithBuyerVerification(collectPostalCode: boolean, paymentSourceId: string, cardEntryConfig: CardEntryConfig, onBuyerVerificationSuccess?: BuyerVerificationSuccessCallback, onBuyerVerificationFailure?: FailureCallback, onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult, onCardEntryCancel?: CancelAndCompleteCallback): void;
    function startGiftCardEntryFlowWithBuyerVerification(paymentSourceId: string, cardEntryConfig: CardEntryConfig, onBuyerVerificationSuccess?: BuyerVerificationSuccessCallback, onBuyerVerificationFailure?: FailureCallback, onCardNonceRequestSuccess?: NonceSuccessCallbackWithResult, onCardEntryCancel?: CancelAndCompleteCallback): void;
    function setIOSCardEntryTheme(theme: ThemeType): void;
}
export declare namespace SQIPBuyer {
    function startBuyerVerificationFlow(paymentSourceId: string, cardEntryConfig: CardEntryConfig, onBuyerVerificationSuccess?: BuyerVerificationSuccessCallback, onBuyerVerificationFailure?: FailureCallback): void;
    function setMockBuyerVerificationSuccess(mockBuyerVerificationSuccess: boolean): void;
}
export declare namespace SQIPGooglePay {
    function initializeGooglePay(squareLocationId: string, environment: GooglePayEnvironment): void;
    function canUseGooglePay(): Promise<boolean>;
    function requestGooglePayNonce(googlePayConfig: GooglePayConfig, onGooglePayNonceRequestSuccess?: NonceSuccessCallback, onGooglePayNonceRequestFailure?: FailureCallback, onGooglePayCanceled?: CancelAndCompleteCallback): Promise<void>;
    function requestGooglePayNonceWithBuyerVerification(paymentSourceId: string, cardEntryConfig: CardEntryConfig, googlePayConfig: GooglePayConfig, onBuyerVerificationSuccess?: BuyerVerificationSuccessCallback, onBuyerVerificationFailure?: FailureCallback, onGooglePayNonceRequestSuccess?: NonceSuccessCallback, onGooglePayNonceRequestFailure?: FailureCallback, onGooglePayCanceled?: CancelAndCompleteCallback): Promise<void>;
    /**
     * @deprecated Use `GooglePayPriceStatus` instead.
     * @example 'import { GooglePayPriceStatus } from "react-native-square-in-app-payments";'
     */
    const TotalPriceStatusNotCurrentlyKnown = GooglePayPriceStatus.TotalPriceStatusNotCurrentlyKnown;
    /**
     * @deprecated Use `GooglePayPriceStatus` instead.
     * @example 'import { GooglePayPriceStatus } from "react-native-square-in-app-payments";'
     */
    const TotalPriceStatusEstimated = GooglePayPriceStatus.TotalPriceStatusEstimated;
    /**
     * @deprecated Use `GooglePayPriceStatus` instead.
     * @example 'import { GooglePayPriceStatus } from "react-native-square-in-app-payments";'
     */
    const TotalPriceStatusFinal = GooglePayPriceStatus.TotalPriceStatusFinal;
    /**
     * @deprecated Use `GooglePayEnvironment` instead.
     * @example 'import { GooglePayEnvironment } from "react-native-square-in-app-payments";'
     */
    const EnvironmentProduction = GooglePayEnvironment.EnvironmentProduction;
    /**
     * @deprecated Use `GooglePayEnvironment` instead.
     * @example 'import { GooglePayEnvironment } from "react-native-square-in-app-payments";'
     */
    const EnvironmentTest = GooglePayEnvironment.EnvironmentTest;
}
export declare namespace SQIPApplePay {
    function initializeApplePay(applePayMerchantId: string): void;
    function canUseApplePay(): Promise<boolean>;
    /**
     * @deprecated now you don't need to call this method manually.
     * use `requestApplePayNonce` with `ApplePayNonceSuccessCallbackWithResult` instead.
     */
    function completeApplePayAuthorization(isSuccess: boolean, errorMessage?: string): void;
    /** @deprecated Use `requestApplePayNonceWithParams` instead. */
    function requestApplePayNonce(applePayConfig: ApplePayConfig, onApplePayNonceRequestSuccess: NonceSuccessCallback, onApplePayNonceRequestFailure: FailureCallback, onApplePayComplete: CancelAndCompleteCallback): Promise<void>;
    function requestApplePayNonce(applePayConfig: ApplePayConfig, onApplePayNonceRequestSuccess?: ApplePayNonceSuccessCallbackWithResult, onApplePayNonceRequestFailure?: FailureCallback, onApplePayComplete?: ApplePayCancelAndCompleteCallback): Promise<void>;
    function requestApplePayNonceWithBuyerVerification(paymentSourceId: string, cardEntryConfig: CardEntryConfig, applePayConfig: ApplePayConfig, onBuyerVerificationSuccess?: BuyerVerificationSuccessCallback, onBuyerVerificationFailure?: FailureCallback, onApplePayNonceRequestSuccess?: ApplePayNonceSuccessCallbackWithResult, onApplePayNonceRequestFailure?: FailureCallback, onApplePayComplete?: ApplePayCancelAndCompleteCallback): Promise<void>;
}
/**
 * @deprecated Use `ErrorCodes` instead.
 * @example 'import { ErrorCodes } from "react-native-square-in-app-payments";'
 */
export declare const SQIPErrorCodes: {
    UsageError: string;
};
//# sourceMappingURL=index.d.ts.map