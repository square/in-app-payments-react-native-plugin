import { type ColorType, type FontType, type ThemeType } from '../types';
export declare function createInAppPaymentsError(ex: any): any;
export declare function createJSError(debugErrorMessage: string): void;
export declare function isNullOrUndefined(value: any): boolean;
export declare function verifyObjectType(value: any, debugErrorMessage: string): void;
export declare function verifyStringType(value: any, debugErrorMessage: string): void;
export declare function verifyIntegerType(value: any, debugErrorMessage: string): void;
export declare function verifyBooleanType(value: any, debugErrorMessage: string): void;
export declare function verifyNumberType(value: any, debugErrorMessage: string): void;
export declare function verifyFontType(value: FontType): void;
export declare function verifyColorType(value: ColorType): void;
export declare function verifyThemeType(value: ThemeType): void;
//# sourceMappingURL=index.d.ts.map