# React Native plugin for In-App Payments SDK
[![in-app-payment-react-native-plugin](https://github.com/square/in-app-payments-react-native-plugin/actions/workflows/main.yml/badge.svg?branch=master)](https://github.com/square/in-app-payments-react-native-plugin/actions/workflows/main.yml)
[![npm version](https://badge.fury.io/js/react-native-square-in-app-payments.svg)](https://badge.fury.io/js/react-native-square-in-app-payments)

The In-App Payments plugin for Square [In-App Payments SDK] is a wrapper for the native Android and iOS SDKs and 
supports the following native In-App Payments SDK versions:

  * iOS: `1.6.3`
  * Android: `1.6.6`

## Additional documentation

In addition to this README, the following is available in the [React Native plugin GitHub repo]:

* [Getting started guide]
* [Enable Apple Pay guide]
* [Enable Google Pay guide]
* [Technical reference]
* [Troubleshooting guide]
* [`docs`] - Root directory for all documentation.
* [`example-expo`] - Root directory of the React Native sample app (with walkthrough).
* [Getting started with the example app]

## Build requirements

### Android

* Android minSdkVersion is API 24 (Nougat, 7.0) or higher.
* Android Target SDK version: API 33 (Android 13).
* Android Gradle Plugin: 4.0.0 or greater.

### iOS

* Xcode version: 15.0 or greater.
* iOS Base SDK: 13.0 or greater.
* Deployment target: iOS 13.0 or greater.

## In-App Payments SDK requirements and limitations

* In-App Payments SDK cannot issue refunds. Refunds can be issued programmatically using
  the Refunds API or manually in the [Square Dashboard].


## Sample applications

### Steps

1. Run yarn 
2. Run yarn prepare
3. cd example-expo
4. Run yarn 
6. Run npx expo prebuild
7. Run yarn ios


## License

```
Copyright 2022 Square Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

[//]: # "Link anchor definitions"
[In-App Payments SDK]: https://developer.squareup.com/docs/in-app-payments-sdk/what-it-does
[Square Dashboard]: https://squareup.com/dashboard/
[Testing Mobile Apps]: https://developer.squareup.com/docs/testing/mobile
[`docs`]: https://github.com/square/in-app-payments-react-native-plugin/tree/master/docs
[`example-expo`]: https://github.com/square/in-app-payments-react-native-plugin/tree/master/example-expo
[Getting started guide]: https://github.com/square/in-app-payments-react-native-plugin/blob/master/docs/get-started.md
[Enable Apple Pay guide]: https://github.com/square/in-app-payments-react-native-plugin/blob/master/docs/enable-applepay.md
[Enable Google Pay guide]: https://github.com/square/in-app-payments-react-native-plugin/blob/master/docs/enable-googlepay.md
[Technical reference]: https://github.com/square/in-app-payments-react-native-plugin/blob/master/docs/reference.md
[Troubleshooting guide]: https://github.com/square/in-app-payments-react-native-plugin/blob/master/docs/troubleshooting.md
[React Native plugin GitHub repo]: https://github.com/square/in-app-payments-react-native-plugin/tree/master
[Getting started with the example app]: https://github.com/square/in-app-payments-react-native-plugin/tree/master/example-expo/README.md
[Quick start React Native app]: https://github.com/square/in-app-payments-react-native-plugin/tree/master/example-expo
